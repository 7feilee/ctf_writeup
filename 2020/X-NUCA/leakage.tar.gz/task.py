#!/usr/bin/env python3
from Crypto.Util.number import *
from secret import FLAG

p = getPrime(1024)
q = getPrime(1024)
r = getPrime(1024)

N = p * q * r
phi = (p-1) * (q-1) * (r-1)

e = 65537
d = inverse(e, phi)

p0 = p - p % getPrime(384)
res_0 = p0 + r
res_1 = p0 * r

pt = bytes_to_long(FLAG)
ct = pow(pt, e, N)

if __name__ == '__main__':
    f = open("output.txt", "wb")
    f.write(str(res_0).encode() + b'\n')
    f.write(str(res_1).encode() + b'\n')
    f.write(str(N).encode() + b'\n')
    f.write(str(ct).encode())
    f.close()