#!/usr/bin/env python3
import os
import random
from Crypto.Util.number import *

from secret import flag

BITS = 1024
ALPHA = 111870718431542817204760874740917337854381793641291611443130732516971588250206941314147925908545375935950062300414955254126017904598353691542186412109594230141753937230485352562899546341549330745453166443772598882098102251794809834501912102258606080

def key_gen(bits, alpha):
	while True:
		p = random.getrandbits(200) * alpha + random.getrandbits(24)
		p |= 2**(bits - 1) | 2**(bits - 2) | 1
		if isPrime(p):
			break
	q = getStrongPrime(bits)
	return (p * q), (p - 1) * (q - 1)

def encrypt(pt, pk):
	n = pk
	r = random.randrange(1, n)
	ct = (pow(n + 1, pt, n**3) * pow(r, n**2, n**3)) % n**3
	return ct

if __name__ == '__main__':
	pk, sk = key_gen(BITS, ALPHA)
	pt = int.from_bytes(flag, 'big')
	ct = encrypt(pt, pk)

	f = open("output.txt", "wb")
	f.write(str(pk).encode() + b'\n')
	f.write(str(ct).encode())
	f.close()